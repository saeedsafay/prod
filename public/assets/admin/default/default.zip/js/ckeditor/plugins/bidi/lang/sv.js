/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'sv', {
	ltr: 'Text riktning från vänster till höger',
	rtl: 'Text riktning från höger till vänster'
} );
