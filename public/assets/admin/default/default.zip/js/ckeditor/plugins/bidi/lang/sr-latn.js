/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'sr-latn', {
	ltr: 'Text direction from left to right', // MISSING
	rtl: 'Text direction from right to left' // MISSING
} );
